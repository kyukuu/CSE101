import itertools

print("Approach 1:")
l1=[1,2,3]
l2=[4,5,6]
l=l1+l2

perm=itertools.permutations(l,2)
for i in perm:
    print(i, end=" ")
print()
print("Approach 2:")
t=[[(i,j) for i in l1] for j in l2]

ans=[]
for i in t:
    for j in i:
        if j not in ans:
            ans.append(j)
print(ans)
